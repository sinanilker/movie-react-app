import "./scss/App.css";
import Navi from "./components/Navi";
import Form from "./components/Form";
import Card from "./components/Card";
import { useEffect, useState } from "react";
import axios from "axios";
import Header from "./components/Header";
import '@fortawesome/fontawesome-svg-core/styles.css'
import SectionFirst from "./components/SectionFirst";


function App() {
  return
}

export default App;
